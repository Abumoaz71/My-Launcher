package com.mohamed.tvlauncher

import java.net.HttpURLConnection
import java.net.URL

object Net {
    /** GET بسيط، يرمي استثناء لو فشل. لازم يتنادى من thread خلفي. */
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.requestMethod = "GET"
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
