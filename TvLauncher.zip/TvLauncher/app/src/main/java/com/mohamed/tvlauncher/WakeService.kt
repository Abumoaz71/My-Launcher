package com.mohamed.tvlauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder

/**
 * خدمة خفيفة شغّالة في الخلفية، بتفتح اللانشر لما الشاشة تصحى من وضع الانتظار
 * (لأن بعض الشاشات بتفتح لانشر المصنّع بدل اللانشر المختار).
 */
class WakeService : Service() {

    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
            if (prefs.getBoolean("autostart", true)) openLauncher(context)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        registerReceiver(wakeReceiver, f)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try {
            unregisterReceiver(wakeReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val title = "لانشر الشاشة شغّال"
        return if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel("wake", "Launcher", NotificationManager.IMPORTANCE_MIN)
            )
            Notification.Builder(this, "wake")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(title)
                .build()
        }
    }

    companion object {
        fun start(ctx: Context) {
            val i = Intent(ctx, WakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        fun openLauncher(ctx: Context) {
            val i = Intent(Intent.ACTION_MAIN)
                .setClass(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            try {
                ctx.startActivity(i)
            } catch (_: Exception) {
            }
        }
    }
}
