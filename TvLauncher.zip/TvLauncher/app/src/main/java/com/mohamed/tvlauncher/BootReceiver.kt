package com.mohamed.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** يشغّل اللانشر تلقائياً بعد إقلاع الشاشة (لو الخيار مفعّل في إعدادات اللانشر). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("autostart", true)) return
        try {
            WakeService.start(context)
        } catch (_: Exception) {
        }
        WakeService.openLauncher(context)
    }
}
