package com.mohamed.tvlauncher

import org.json.JSONObject
import java.net.URLEncoder

/** مكان (مدينة/محافظة) مع إحداثياته ومنطقته الزمنية وطريقة حساب الصلاة المناسبة له */
data class Place(
    val ar: String,
    val en: String,
    val lat: Double,
    val lon: Double,
    val tz: String,
    val method: Int,
    val sub: String = ""
)

data class Country(val ar: String, val en: String, val places: List<Place>)

/** طريقة حساب مواقيت الصلاة (أرقام Aladhan). id = -1 يعني تلقائي حسب الموقع */
data class CalcMethod(val id: Int, val ar: String, val en: String)

data class Theme(val ar: String, val en: String, val accent: Int, val top: Int, val bottom: Int)

object Places {

    val themes = listOf(
        Theme("أزرق", "Blue", 0xFF1E7BFF.toInt(), 0x081028, 0x1B1F5E),
        Theme("أخضر زمردي", "Emerald", 0xFF10B981.toInt(), 0x051A14, 0x0B3B2E),
        Theme("بنفسجي", "Purple", 0xFF8B5CF6.toInt(), 0x120A28, 0x2E1B5E),
        Theme("ذهبي", "Gold", 0xFFF59E0B.toInt(), 0x1A1205, 0x3B2A0B),
        Theme("أحمر", "Crimson", 0xFFE11D48.toInt(), 0x1A050B, 0x4A0D1E),
        Theme("رمادي داكن", "Graphite", 0xFF64748B.toInt(), 0x0A0A0A, 0x1F2933)
    )

    val methods = listOf(
        CalcMethod(-1, "تلقائي (حسب الموقع)", "Auto (by location)"),
        CalcMethod(5, "الهيئة المصرية العامة للمساحة", "Egyptian General Authority of Survey"),
        CalcMethod(4, "أم القرى (مكة المكرمة)", "Umm Al-Qura (Makkah)"),
        CalcMethod(3, "رابطة العالم الإسلامي", "Muslim World League"),
        CalcMethod(2, "أمريكا الشمالية (ISNA)", "North America (ISNA)"),
        CalcMethod(1, "جامعة العلوم الإسلامية بكراتشي", "Karachi"),
        CalcMethod(8, "منطقة الخليج", "Gulf Region"),
        CalcMethod(9, "الكويت", "Kuwait"),
        CalcMethod(10, "قطر", "Qatar"),
        CalcMethod(23, "الأردن", "Jordan"),
        CalcMethod(18, "تونس", "Tunisia"),
        CalcMethod(19, "الجزائر", "Algeria"),
        CalcMethod(21, "المغرب", "Morocco"),
        CalcMethod(13, "تركيا (ديانت)", "Turkey (Diyanet)")
    )

    private fun p(ar: String, en: String, lat: Double, lon: Double, tz: String, m: Int) =
        Place(ar, en, lat, lon, tz, m)

    val countries: List<Country> = listOf(
        Country("مصر", "Egypt", listOf(
            p("القاهرة", "Cairo", 30.0444, 31.2357, "Africa/Cairo", 5),
            p("الجيزة", "Giza", 30.0131, 31.2089, "Africa/Cairo", 5),
            p("الإسكندرية", "Alexandria", 31.2001, 29.9187, "Africa/Cairo", 5),
            p("بورسعيد", "Port Said", 31.2653, 32.3019, "Africa/Cairo", 5),
            p("السويس", "Suez", 29.9668, 32.5498, "Africa/Cairo", 5),
            p("الإسماعيلية", "Ismailia", 30.5965, 32.2715, "Africa/Cairo", 5),
            p("دمياط", "Damietta", 31.4165, 31.8133, "Africa/Cairo", 5),
            p("الدقهلية (المنصورة)", "Dakahlia (Mansoura)", 31.0364, 31.3807, "Africa/Cairo", 5),
            p("الشرقية (الزقازيق)", "Sharqia (Zagazig)", 30.5877, 31.5020, "Africa/Cairo", 5),
            p("القليوبية (بنها)", "Qalyubia (Banha)", 30.4660, 31.1848, "Africa/Cairo", 5),
            p("الغربية (طنطا)", "Gharbia (Tanta)", 30.7865, 31.0004, "Africa/Cairo", 5),
            p("المنوفية (شبين الكوم)", "Monufia (Shibin El Kom)", 30.5972, 30.9876, "Africa/Cairo", 5),
            p("كفر الشيخ", "Kafr El Sheikh", 31.1107, 30.9388, "Africa/Cairo", 5),
            p("البحيرة (دمنهور)", "Beheira (Damanhur)", 31.0409, 30.4717, "Africa/Cairo", 5),
            p("مطروح", "Matrouh", 31.3543, 27.2373, "Africa/Cairo", 5),
            p("الفيوم", "Fayoum", 29.3084, 30.8428, "Africa/Cairo", 5),
            p("بني سويف", "Beni Suef", 29.0661, 31.0994, "Africa/Cairo", 5),
            p("المنيا", "Minya", 28.1099, 30.7503, "Africa/Cairo", 5),
            p("أسيوط", "Asyut", 27.1809, 31.1837, "Africa/Cairo", 5),
            p("سوهاج", "Sohag", 26.5591, 31.6948, "Africa/Cairo", 5),
            p("قنا", "Qena", 26.1551, 32.7160, "Africa/Cairo", 5),
            p("الأقصر", "Luxor", 25.6872, 32.6396, "Africa/Cairo", 5),
            p("أسوان", "Aswan", 24.0889, 32.8998, "Africa/Cairo", 5),
            p("البحر الأحمر (الغردقة)", "Red Sea (Hurghada)", 27.2579, 33.8116, "Africa/Cairo", 5),
            p("الوادي الجديد (الخارجة)", "New Valley (Kharga)", 25.4390, 30.5586, "Africa/Cairo", 5),
            p("شمال سيناء (العريش)", "North Sinai (Arish)", 31.1316, 33.7984, "Africa/Cairo", 5),
            p("جنوب سيناء (الطور)", "South Sinai (El Tor)", 28.2410, 33.6222, "Africa/Cairo", 5),
            p("شرم الشيخ", "Sharm El Sheikh", 27.9158, 34.3300, "Africa/Cairo", 5)
        )),
        Country("السعودية", "Saudi Arabia", listOf(
            p("الرياض", "Riyadh", 24.7136, 46.6753, "Asia/Riyadh", 4),
            p("مكة المكرمة", "Makkah", 21.3891, 39.8579, "Asia/Riyadh", 4),
            p("المدينة المنورة", "Madinah", 24.5247, 39.5692, "Asia/Riyadh", 4),
            p("جدة", "Jeddah", 21.4858, 39.1925, "Asia/Riyadh", 4),
            p("الدمام", "Dammam", 26.4207, 50.0888, "Asia/Riyadh", 4),
            p("الطائف", "Taif", 21.2703, 40.4158, "Asia/Riyadh", 4),
            p("أبها", "Abha", 18.2164, 42.5053, "Asia/Riyadh", 4),
            p("تبوك", "Tabuk", 28.3838, 36.5550, "Asia/Riyadh", 4),
            p("بريدة", "Buraydah", 26.3260, 43.9750, "Asia/Riyadh", 4),
            p("حائل", "Hail", 27.5114, 41.7208, "Asia/Riyadh", 4)
        )),
        Country("الإمارات", "UAE", listOf(
            p("أبوظبي", "Abu Dhabi", 24.4539, 54.3773, "Asia/Dubai", 8),
            p("دبي", "Dubai", 25.2048, 55.2708, "Asia/Dubai", 8),
            p("الشارقة", "Sharjah", 25.3463, 55.4209, "Asia/Dubai", 8),
            p("عجمان", "Ajman", 25.4052, 55.5136, "Asia/Dubai", 8),
            p("العين", "Al Ain", 24.2075, 55.7447, "Asia/Dubai", 8),
            p("رأس الخيمة", "Ras Al Khaimah", 25.7895, 55.9432, "Asia/Dubai", 8)
        )),
        Country("الكويت", "Kuwait", listOf(
            p("مدينة الكويت", "Kuwait City", 29.3759, 47.9774, "Asia/Kuwait", 9),
            p("الأحمدي", "Ahmadi", 29.0769, 48.0838, "Asia/Kuwait", 9),
            p("الجهراء", "Jahra", 29.3375, 47.6581, "Asia/Kuwait", 9)
        )),
        Country("قطر", "Qatar", listOf(
            p("الدوحة", "Doha", 25.2854, 51.5310, "Asia/Qatar", 10),
            p("الريان", "Al Rayyan", 25.2919, 51.4244, "Asia/Qatar", 10),
            p("الوكرة", "Al Wakrah", 25.1715, 51.6034, "Asia/Qatar", 10)
        )),
        Country("البحرين", "Bahrain", listOf(
            p("المنامة", "Manama", 26.2285, 50.5860, "Asia/Bahrain", 8),
            p("المحرق", "Muharraq", 26.2572, 50.6119, "Asia/Bahrain", 8)
        )),
        Country("عُمان", "Oman", listOf(
            p("مسقط", "Muscat", 23.5880, 58.3829, "Asia/Muscat", 8),
            p("صلالة", "Salalah", 17.0151, 54.0924, "Asia/Muscat", 8),
            p("صحار", "Sohar", 24.3417, 56.7292, "Asia/Muscat", 8)
        )),
        Country("الأردن", "Jordan", listOf(
            p("عمّان", "Amman", 31.9454, 35.9284, "Asia/Amman", 23),
            p("إربد", "Irbid", 32.5556, 35.8500, "Asia/Amman", 23),
            p("الزرقاء", "Zarqa", 32.0728, 36.0880, "Asia/Amman", 23),
            p("العقبة", "Aqaba", 29.5321, 35.0063, "Asia/Amman", 23)
        )),
        Country("فلسطين", "Palestine", listOf(
            p("القدس", "Jerusalem", 31.7683, 35.2137, "Asia/Hebron", 3),
            p("غزة", "Gaza", 31.5017, 34.4668, "Asia/Gaza", 3),
            p("رام الله", "Ramallah", 31.9038, 35.2034, "Asia/Hebron", 3),
            p("نابلس", "Nablus", 32.2211, 35.2544, "Asia/Hebron", 3),
            p("الخليل", "Hebron", 31.5326, 35.0998, "Asia/Hebron", 3)
        )),
        Country("لبنان", "Lebanon", listOf(
            p("بيروت", "Beirut", 33.8938, 35.5018, "Asia/Beirut", 3),
            p("طرابلس", "Tripoli", 34.4367, 35.8497, "Asia/Beirut", 3),
            p("صيدا", "Sidon", 33.5630, 35.3688, "Asia/Beirut", 3)
        )),
        Country("سوريا", "Syria", listOf(
            p("دمشق", "Damascus", 33.5138, 36.2765, "Asia/Damascus", 3),
            p("حلب", "Aleppo", 36.2021, 37.1343, "Asia/Damascus", 3),
            p("حمص", "Homs", 34.7324, 36.7137, "Asia/Damascus", 3),
            p("اللاذقية", "Latakia", 35.5317, 35.7898, "Asia/Damascus", 3)
        )),
        Country("العراق", "Iraq", listOf(
            p("بغداد", "Baghdad", 33.3152, 44.3661, "Asia/Baghdad", 3),
            p("البصرة", "Basra", 30.5085, 47.7804, "Asia/Baghdad", 3),
            p("الموصل", "Mosul", 36.3350, 43.1189, "Asia/Baghdad", 3),
            p("أربيل", "Erbil", 36.1901, 44.0091, "Asia/Baghdad", 3),
            p("النجف", "Najaf", 31.9961, 44.3363, "Asia/Baghdad", 3)
        )),
        Country("اليمن", "Yemen", listOf(
            p("صنعاء", "Sanaa", 15.3694, 44.1910, "Asia/Aden", 3),
            p("عدن", "Aden", 12.7855, 45.0187, "Asia/Aden", 3),
            p("تعز", "Taiz", 13.5795, 44.0209, "Asia/Aden", 3)
        )),
        Country("ليبيا", "Libya", listOf(
            p("طرابلس", "Tripoli", 32.8872, 13.1913, "Africa/Tripoli", 3),
            p("بنغازي", "Benghazi", 32.1167, 20.0667, "Africa/Tripoli", 3),
            p("مصراتة", "Misrata", 32.3754, 15.0925, "Africa/Tripoli", 3)
        )),
        Country("تونس", "Tunisia", listOf(
            p("تونس", "Tunis", 36.8065, 10.1815, "Africa/Tunis", 18),
            p("صفاقس", "Sfax", 34.7406, 10.7603, "Africa/Tunis", 18),
            p("سوسة", "Sousse", 35.8256, 10.6369, "Africa/Tunis", 18)
        )),
        Country("الجزائر", "Algeria", listOf(
            p("الجزائر", "Algiers", 36.7538, 3.0588, "Africa/Algiers", 19),
            p("وهران", "Oran", 35.6971, -0.6308, "Africa/Algiers", 19),
            p("قسنطينة", "Constantine", 36.3650, 6.6147, "Africa/Algiers", 19)
        )),
        Country("المغرب", "Morocco", listOf(
            p("الرباط", "Rabat", 34.0209, -6.8416, "Africa/Casablanca", 21),
            p("الدار البيضاء", "Casablanca", 33.5731, -7.5898, "Africa/Casablanca", 21),
            p("فاس", "Fes", 34.0181, -5.0078, "Africa/Casablanca", 21),
            p("مراكش", "Marrakesh", 31.6295, -7.9811, "Africa/Casablanca", 21),
            p("طنجة", "Tangier", 35.7595, -5.8340, "Africa/Casablanca", 21)
        )),
        Country("السودان", "Sudan", listOf(
            p("الخرطوم", "Khartoum", 15.5007, 32.5599, "Africa/Khartoum", 3),
            p("أم درمان", "Omdurman", 15.6445, 32.4777, "Africa/Khartoum", 3),
            p("بورتسودان", "Port Sudan", 19.6158, 37.2164, "Africa/Khartoum", 3)
        )),
        Country("تركيا", "Turkey", listOf(
            p("إسطنبول", "Istanbul", 41.0082, 28.9784, "Europe/Istanbul", 13),
            p("أنقرة", "Ankara", 39.9334, 32.8597, "Europe/Istanbul", 13),
            p("إزمير", "Izmir", 38.4237, 27.1428, "Europe/Istanbul", 13)
        )),
        Country("المملكة المتحدة", "United Kingdom", listOf(
            p("لندن", "London", 51.5072, -0.1276, "Europe/London", 3),
            p("مانشستر", "Manchester", 53.4808, -2.2426, "Europe/London", 3)
        )),
        Country("ألمانيا", "Germany", listOf(
            p("برلين", "Berlin", 52.5200, 13.4050, "Europe/Berlin", 3),
            p("ميونخ", "Munich", 48.1351, 11.5820, "Europe/Berlin", 3)
        )),
        Country("فرنسا", "France", listOf(
            p("باريس", "Paris", 48.8566, 2.3522, "Europe/Paris", 12),
            p("مرسيليا", "Marseille", 43.2965, 5.3698, "Europe/Paris", 12)
        )),
        Country("الولايات المتحدة", "United States", listOf(
            p("نيويورك", "New York", 40.7128, -74.0060, "America/New_York", 2),
            p("شيكاغو", "Chicago", 41.8781, -87.6298, "America/Chicago", 2),
            p("لوس أنجلوس", "Los Angeles", 34.0522, -118.2437, "America/Los_Angeles", 2)
        )),
        Country("كندا", "Canada", listOf(
            p("تورنتو", "Toronto", 43.6532, -79.3832, "America/Toronto", 2),
            p("مونتريال", "Montreal", 45.5017, -73.5673, "America/Toronto", 2)
        ))
    )

    /** طريقة الحساب الأنسب حسب رمز الدولة (للنتائج القادمة من البحث) */
    fun methodFor(cc: String): Int = when (cc.uppercase()) {
        "EG" -> 5
        "SA" -> 4
        "AE", "BH", "OM" -> 8
        "KW" -> 9
        "QA" -> 10
        "JO" -> 23
        "TN" -> 18
        "DZ" -> 19
        "MA" -> 21
        "TR" -> 13
        "FR" -> 12
        "US", "CA" -> 2
        "PK", "IN", "BD", "AF" -> 1
        "MY" -> 17
        "SG" -> 11
        "ID" -> 20
        "PT" -> 22
        "RU" -> 14
        "IR" -> 7
        else -> 3
    }

    /** بحث عن أي مدينة في العالم (Open-Meteo Geocoding). لازم يتنادى من thread خلفي. */
    fun search(query: String, lang: String): List<Place> {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                URLEncoder.encode(query, "UTF-8") + "&count=10&language=$lang&format=json"
        val res = JSONObject(Net.get(url)).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Place>()
        for (i in 0 until res.length()) {
            val o = res.getJSONObject(i)
            val tz = o.optString("timezone", "")
            if (tz.isEmpty()) continue
            val name = o.optString("name", "")
            val admin = o.optString("admin1", "")
            val country = o.optString("country", "")
            val label = listOf(name, admin, country)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString(if (lang == "ar") "، " else ", ")
            out.add(
                Place(
                    name, name,
                    o.getDouble("latitude"), o.getDouble("longitude"),
                    tz, methodFor(o.optString("country_code", "")), label
                )
            )
        }
        return out
    }
}
