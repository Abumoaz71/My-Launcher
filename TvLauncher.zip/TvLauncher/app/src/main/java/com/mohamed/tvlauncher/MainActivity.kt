package com.mohamed.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvView
import android.view.KeyEvent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class AppItem(val pkg: String, val label: String, val launch: Intent)

class MainActivity : Activity() {

    // ---------- حالة عامة ----------
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var uiLayer: FrameLayout
    private lateinit var dim: View
    private lateinit var tvView: TvView
    private var tvPlaying = false
    private var overlaysHidden = false
    private var scale = 1f

    private var installed: List<AppItem> = emptyList()
    private val iconCache = HashMap<String, Drawable?>()

    private val tabLabels = linkedMapOf(
        "settings" to "الإعدادات",
        "bluetooth" to "بلوتوث",
        "inputs" to "المداخل",
        "network" to "الشبكة",
        "apps" to "التطبيقات",
        "home" to "الرئيسية"
    )
    private val tabViews = LinkedHashMap<String, TextView>()
    private var selectedTab = "home"

    private lateinit var homeLayer: FrameLayout
    private lateinit var appsLayer: FrameLayout
    private lateinit var appsGrid: GridView
    private lateinit var tileRow: LinearLayout

    private lateinit var weatherTv: TextView
    private lateinit var currencyTv: TextView
    private lateinit var hijriTv: TextView
    private lateinit var gregTv: TextView
    private lateinit var remainTv: TextView
    private lateinit var tickerBar: View
    private lateinit var tickerTv: TextView

    private val prayerLabels = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
    private val prayerKeys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val countdownIdx = listOf(0, 2, 3, 4, 5) // الشروق مش صلاة في العد التنازلي
    private val prayerRows = ArrayList<View>()
    private val prayerTimeTvs = ArrayList<TextView>()
    private var prayerMinutes: List<Int>? = null
    private var prayerStrings: List<String>? = null
    private var hijriText: String = ""

    private var lastRefresh = 0L

    private val tick = object : Runnable {
        override fun run() {
            updatePrayerUi()
            updateGregorian()
            ui.postDelayed(this, 15_000)
        }
    }

    // ---------- دورة الحياة ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        val dm = resources.displayMetrics
        scale = minOf(dm.widthPixels / 1920f, dm.heightPixels / 1080f)

        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.clipChildren = false

        // الطبقات من تحت لفوق: القناة (HDMI) ← تعتيم خفيف ← الواجهة
        tvView = TvView(this)
        tvView.visibility = View.GONE
        tvView.setCallback(object : TvView.TvInputCallback() {
            override fun onConnectionFailed(inputId: String?) {
                runOnUiThread { stopTv(); toast("تعذّر تشغيل المدخل") }
            }

            override fun onDisconnected(inputId: String?) {
                runOnUiThread { stopTv() }
            }
        })
        root.addView(tvView, FrameLayout.LayoutParams(-1, -1))
        dim = View(this)
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))
        setDim(false)
        uiLayer = FrameLayout(this)
        uiLayer.layoutDirection = View.LAYOUT_DIRECTION_LTR
        uiLayer.clipChildren = false
        root.addView(uiLayer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildTopBar()
        buildHome()
        buildApps()

        installed = loadInstalled()
        applyCachedPrayer()
        showHome()
    }

    override fun onResume() {
        super.onResume()
        installed = loadInstalled()
        (appsGrid.adapter as? BaseAdapter)?.notifyDataSetChanged()
        rebuildHomeRow()
        resumeTv()
        ui.removeCallbacks(tick)
        tick.run()
        val now = System.currentTimeMillis()
        if (now - lastRefresh > Config.REFRESH_MINUTES * 60_000L) {
            lastRefresh = now
            refreshAll()
        }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        // نوقف القناة لما نطلع لتطبيق تاني، ونرجّعها في onResume
        tvView.reset()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) {
            setOverlays(true)
            showHome()
            tabViews["home"]?.requestFocus()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // اللانشر ما بيقفلش
        if (selectedTab != "home") {
            showHome()
            tabViews["home"]?.requestFocus()
        } else if (tvPlaying) {
            setOverlays(false) // إخفاء الواجهة وإظهار القناة بس
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (overlaysHidden) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE -> return super.dispatchKeyEvent(event)
            }
            // أي زرار تاني يرجّع الواجهة
            if (event.action == KeyEvent.ACTION_DOWN) setOverlays(true)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------- القناة في الخلفية (مدخل HDMI) ----------
    private fun setDim(tvOn: Boolean) {
        val top = if (tvOn) 0x73081028L else 0xB3081028L
        val bottom = if (tvOn) 0x661B1F5EL else 0x8C1B1F5EL
        dim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(top.toInt(), bottom.toInt())
        )
    }

    private fun setOverlays(show: Boolean) {
        overlaysHidden = !show
        uiLayer.visibility = if (show) View.VISIBLE else View.GONE
        dim.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            if (selectedTab == "apps") appsGrid.requestFocus() else tabViews["home"]?.requestFocus()
        }
    }

    private fun inputManager(): TvInputManager? =
        getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager

    private fun hdmiInputs(): List<TvInputInfo> = try {
        inputManager()?.tvInputList?.filter { it.isPassthroughInput } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    private fun startInput(info: TvInputInfo) {
        try {
            tvView.visibility = View.VISIBLE
            tvView.setStreamVolume(1f)
            tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
            prefs.edit().putString("input_id", info.id).apply()
            tvPlaying = true
            setDim(true)
        } catch (_: Exception) {
            stopTv()
            toast("تعذّر تشغيل المدخل")
        }
    }

    private fun stopTv() {
        try { tvView.reset() } catch (_: Exception) {}
        tvView.visibility = View.GONE
        tvPlaying = false
        setDim(false)
        if (overlaysHidden) setOverlays(true)
    }

    private fun resumeTv() {
        val saved = prefs.getString("input_id", null) ?: return
        val info = hdmiInputs().firstOrNull { it.id == saved } ?: return
        startInput(info)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    // ---------- أدوات رسم ----------
    private fun px(v: Int): Int = (v * scale + 0.5f).toInt()

    private fun glass(radius: Int, fill: Int, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = px(radius).toFloat()
            setColor(fill)
            if (strokeW > 0) setStroke(px(strokeW), stroke)
        }

    private fun text(
        s: String,
        size: Int,
        color: Int = Color.WHITE,
        bold: Boolean = false,
        gravity: Int = Gravity.END or Gravity.CENTER_VERTICAL
    ): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size).toFloat())
        setTextColor(color)
        this.gravity = gravity
        includeFontPadding = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun FrameLayout.put(v: View, x: Int, y: Int, w: Int, h: Int) {
        val lp = FrameLayout.LayoutParams(px(w), px(h))
        lp.leftMargin = px(x)
        lp.topMargin = px(y)
        addView(v, lp)
    }

    private fun roundOutline(r: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, px(r).toFloat())
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- الشريط العلوي ----------
    private fun buildTopBar() {
        val bar = View(this)
        bar.background = glass(44, 0x26FFFFFF, 0x40FFFFFF, 2)
        uiLayer.put(bar, 90, 14, 1740, 86)

        weatherTv = text("${Config.CITY_AR} --°", 26, 0xFFBFD4FF.toInt(), gravity = Gravity.START or Gravity.CENTER_VERTICAL)
        uiLayer.put(weatherTv, 125, 22, 340, 34)
        currencyTv = text("${Config.CURRENCY_LABEL}: --", 26, 0xFF7DB8FF.toInt(), gravity = Gravity.START or Gravity.CENTER_VERTICAL)
        uiLayer.put(currencyTv, 125, 58, 340, 34)

        val owner = text(Config.OWNER_NAME, 32, bold = true)
        uiLayer.put(owner, 1560, 28, 250, 56)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER
        row.clipChildren = false
        uiLayer.put(row, 480, 24, 1080, 66)

        for ((id, label) in tabLabels) {
            val tv = text(label, 30, gravity = Gravity.CENTER)
            tv.isFocusable = true
            tv.isClickable = true
            tv.setPadding(px(34), 0, px(34), 0)
            tv.setOnFocusChangeListener { _, _ -> styleTab(id) }
            tv.setOnClickListener { openTab(id) }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, px(62))
            lp.leftMargin = px(8)
            lp.rightMargin = px(8)
            row.addView(tv, lp)
            tabViews[id] = tv
        }
        styleAllTabs()
    }

    private fun styleTab(id: String) {
        val tv = tabViews[id] ?: return
        val selected = id == selectedTab
        val fill = if (selected) 0xFF1E7BFF.toInt() else 0
        val stroke = if (tv.isFocused) 0xFF4DA3FF.toInt() else 0
        tv.background = glass(31, fill, stroke, 3)
    }

    private fun styleAllTabs() = tabViews.keys.forEach { styleTab(it) }

    private fun openTab(id: String) {
        when (id) {
            "home" -> showHome()
            "apps" -> showApps()
            "network" -> startFirst(
                Intent(Settings.ACTION_WIFI_SETTINGS),
                Intent(Settings.ACTION_WIRELESS_SETTINGS)
            )
            "bluetooth" -> startFirst(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "settings" -> startFirst(Intent(Settings.ACTION_SETTINGS))
            "inputs" -> openInputs()
        }
    }

    private fun startFirst(vararg intents: Intent) {
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        toast("الصفحة دي مش متاحة على الشاشة")
    }

    private fun openInputs() {
        val inputs = hdmiInputs()
        if (inputs.isEmpty()) {
            openInputsFallback()
            return
        }
        val names = inputs.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }.toMutableList()
        names.add("إيقاف القناة في الخلفية")
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("اختر المدخل")
            .setItems(names.toTypedArray()) { _, i ->
                if (i < inputs.size) {
                    startInput(inputs[i])
                    showHome()
                    tabViews["home"]?.requestFocus()
                } else {
                    prefs.edit().remove("input_id").apply()
                    stopTv()
                }
            }
            .show()
    }

    private fun openInputsFallback() {
        for (p in Config.INPUT_PACKAGES) {
            val i = packageManager.getLeanbackLaunchIntentForPackage(p)
                ?: packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                try {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                    return
                } catch (_: Exception) {
                }
            }
        }
        toast("عدّل INPUT_PACKAGES في Config.kt لتطبيق المداخل بتاع شاشتك")
    }

    // ---------- الصفحة الرئيسية ----------
    private fun buildHome() {
        homeLayer = FrameLayout(this)
        homeLayer.clipChildren = false
        uiLayer.addView(homeLayer, FrameLayout.LayoutParams(-1, -1))

        // كارت مواقيت الصلاة
        val card = FrameLayout(this)
        card.clipChildren = false
        card.background = glass(46, 0x1FFFFFFF, 0x33FFFFFF, 2)
        homeLayer.put(card, 125, 130, 770, 590)

        card.put(text("مواقيت الصلاة • ${Config.CITY_AR}", 36, bold = true), 24, 20, 722, 50)
        remainTv = text("", 26, 0xFF4DA3FF.toInt())
        card.put(remainTv, 24, 68, 722, 38)

        prayerLabels.forEachIndexed { i, name ->
            val y = 118 + i * 78
            val rowBg = View(this)
            card.put(rowBg, 18, y, 734, 70)
            prayerRows.add(rowBg)
            card.put(text(name, 34, gravity = Gravity.END or Gravity.CENTER_VERTICAL), 300, y, 432, 70)
            val t = text("--:--", 34, gravity = Gravity.START or Gravity.CENTER_VERTICAL)
            card.put(t, 44, y, 230, 70)
            prayerTimeTvs.add(t)
        }

        // التاريخ والساعة
        hijriTv = text("", 42, bold = true)
        homeLayer.put(hijriTv, 1050, 150, 810, 60)
        gregTv = text("", 30, 0xCCFFFFFF.toInt())
        homeLayer.put(gregTv, 1050, 212, 810, 42)

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "h:mm"
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(250).toFloat())
        clock.setTextColor(0xEBFFFFFF.toInt())
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.includeFontPadding = false
        clock.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        homeLayer.put(clock, 1000, 270, 880, 270)

        homeLayer.put(text("توقيت ${Config.CITY_AR}", 28, 0xB3FFFFFF.toInt()), 1050, 545, 810, 40)

        // شريط المباريات
        val bar = FrameLayout(this)
        bar.background = glass(30, 0x26FFFFFF, 0x40FFFFFF, 2)
        homeLayer.put(bar, 125, 748, 1735, 62)
        tickerBar = bar
        val chip = text("المباريات", 26, gravity = Gravity.CENTER)
        chip.background = glass(24, 0xFF1E7BFF.toInt())
        bar.put(chip, 1735 - 176 - 12, 8, 176, 46)
        tickerTv = text("", 28, gravity = Gravity.END or Gravity.CENTER_VERTICAL)
        tickerTv.setSingleLine(true)
        tickerTv.ellipsize = TextUtils.TruncateAt.MARQUEE
        tickerTv.marqueeRepeatLimit = -1
        tickerTv.isSelected = true
        bar.put(tickerTv, 28, 6, 1735 - 176 - 70, 50)
        bar.visibility = View.GONE

        // لوحة التطبيقات
        val panel = FrameLayout(this)
        panel.clipChildren = false
        panel.background = glass(44, 0x26FFFFFF, 0x40FFFFFF, 2)
        homeLayer.put(panel, 275, 850, 1450, 190)

        val hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        hsv.clipToPadding = false
        hsv.clipChildren = false
        hsv.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hsv.setPadding(px(24), 0, px(24), 0)
        tileRow = LinearLayout(this)
        tileRow.orientation = LinearLayout.HORIZONTAL
        tileRow.gravity = Gravity.CENTER_VERTICAL
        tileRow.clipChildren = false
        hsv.addView(tileRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        panel.put(hsv, 0, 0, 1450, 190)
    }

    private fun showHome() {
        selectedTab = "home"
        homeLayer.visibility = View.VISIBLE
        appsLayer.visibility = View.GONE
        styleAllTabs()
    }

    private fun showApps() {
        selectedTab = "apps"
        homeLayer.visibility = View.GONE
        appsLayer.visibility = View.VISIBLE
        styleAllTabs()
        appsGrid.requestFocus()
        if (installed.isNotEmpty()) appsGrid.setSelection(0)
    }

    // ---------- شاشة كل التطبيقات ----------
    private fun buildApps() {
        appsLayer = FrameLayout(this)
        appsLayer.clipChildren = false
        uiLayer.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        appsGrid = GridView(this).apply {
            numColumns = 7
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = px(14)
            horizontalSpacing = px(10)
            gravity = Gravity.CENTER
            clipToPadding = false
            setPadding(px(10), px(14), px(10), px(14))
            isFocusable = true
            selector = glass(28, 0x40FFFFFF, 0xFFFFFFFF.toInt(), 3)
            adapter = AppsAdapter()
            setOnItemClickListener { _, _, p, _ -> launch(installed[p]) }
            setOnItemLongClickListener { _, _, p, _ -> addToHome(installed[p]); true }
        }
        appsLayer.put(appsGrid, 150, 130, 1620, 840)
        appsLayer.put(
            text("اضغط مطوّلاً على أي تطبيق لإضافته للصفحة الرئيسية", 26, 0xB3FFFFFF.toInt(), gravity = Gravity.CENTER),
            150, 985, 1620, 44
        )
        appsLayer.visibility = View.GONE
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = installed.size
        override fun getItem(position: Int) = installed[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = installed[position]
            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.layoutParams = AbsListView.LayoutParams(px(220), px(180))
            val iv = ImageView(this@MainActivity)
            iv.setImageDrawable(iconFor(app.pkg))
            col.addView(iv, LinearLayout.LayoutParams(px(96), px(96)))
            val tv = text(app.label, 24, gravity = Gravity.CENTER)
            tv.setSingleLine(true)
            tv.ellipsize = TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(px(200), px(44))
            lp.topMargin = px(10)
            col.addView(tv, lp)
            return col
        }
    }

    private fun iconFor(pkg: String): Drawable? = iconCache.getOrPut(pkg) {
        runCatching { packageManager.getApplicationIcon(pkg) }.getOrNull()
    }

    // ---------- التطبيقات ----------
    private fun loadInstalled(): List<AppItem> {
        val pm = packageManager
        val map = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName == packageName || map.containsKey(ai.packageName)) continue
                val li = Intent(Intent.ACTION_MAIN)
                    .addCategory(cat)
                    .setClassName(ai.packageName, ai.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                map[ai.packageName] = AppItem(ai.packageName, ri.loadLabel(pm).toString(), li)
            }
        }
        return map.values.sortedBy { it.label.lowercase() }
    }

    private fun launch(app: AppItem) {
        try {
            startActivity(app.launch)
        } catch (_: Exception) {
            toast("تعذّر فتح ${app.label}")
        }
    }

    private fun homePackages(): MutableList<String> {
        val saved = prefs.getString("home_apps", null)
        if (saved != null) return saved.split(",").filter { it.isNotBlank() }.toMutableList()
        val have = installed.map { it.pkg }.toSet()
        val list = mutableListOf<String>()
        for (alts in Config.DEFAULT_APPS) alts.firstOrNull { it in have }?.let { list.add(it) }
        return list
    }

    private fun saveHome(list: List<String>) {
        prefs.edit().putString("home_apps", list.joinToString(",")).apply()
    }

    private fun addToHome(app: AppItem) {
        val l = homePackages()
        if (app.pkg in l) {
            toast("${app.label} موجود بالفعل في الرئيسية")
        } else {
            l.add(app.pkg)
            saveHome(l)
            toast("اتضاف ${app.label} للرئيسية")
        }
    }

    private fun removeFromHome(app: AppItem) {
        val l = homePackages()
        l.remove(app.pkg)
        saveHome(l)
        rebuildHomeRow()
        tileRow.getChildAt(0)?.requestFocus()
        toast("اتشال ${app.label} من الرئيسية")
    }

    private fun rebuildHomeRow() {
        tileRow.removeAllViews()
        val byPkg = installed.associateBy { it.pkg }
        for (p in homePackages()) {
            val app = byPkg[p] ?: continue
            tileRow.addView(makeAppTile(app), tileLp())
        }
        tileRow.addView(makeAddTile(), tileLp())
    }

    private fun tileLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(px(250), px(130))
        lp.leftMargin = px(14)
        lp.rightMargin = px(14)
        return lp
    }

    private fun focusEffect(tile: View, radius: Int) {
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = px(radius).toFloat()
            setColor(0)
            setStroke(px(4), Color.WHITE)
        }
        tile.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            v.translationZ = if (focused) 12f else 0f
            v.foreground = if (focused) ring else null
        }
    }

    private fun makeAppTile(app: AppItem): View {
        val tile = FrameLayout(this)
        tile.background = glass(24, 0x30FFFFFF)
        tile.isFocusable = true
        tile.isClickable = true
        val banner = runCatching { packageManager.getApplicationBanner(app.pkg) }.getOrNull()
        if (banner != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(banner)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.clipToOutline = true
            iv.outlineProvider = roundOutline(24)
            tile.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val iv = ImageView(this)
            iv.setImageDrawable(iconFor(app.pkg))
            col.addView(iv, LinearLayout.LayoutParams(px(64), px(64)))
            val tv = text(app.label, 24, gravity = Gravity.CENTER)
            tv.setSingleLine(true)
            tv.ellipsize = TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(px(220), px(34))
            lp.topMargin = px(6)
            col.addView(tv, lp)
            tile.addView(col, FrameLayout.LayoutParams(-1, -1))
        }
        focusEffect(tile, 24)
        tile.setOnClickListener { launch(app) }
        tile.setOnLongClickListener { removeFromHome(app); true }
        return tile
    }

    private fun makeAddTile(): View {
        val tile = FrameLayout(this)
        tile.background = glass(24, 0x1FFFFFFF, 0x40FFFFFF, 2)
        tile.isFocusable = true
        tile.isClickable = true
        tile.addView(text("+", 70, gravity = Gravity.CENTER), FrameLayout.LayoutParams(-1, -1))
        focusEffect(tile, 24)
        tile.setOnClickListener {
            showApps()
            toast("اضغط مطوّلاً على التطبيق لإضافته")
        }
        return tile
    }

    // ---------- التاريخ ----------
    private fun updateGregorian() {
        val f = SimpleDateFormat("EEEE، d MMMM", Locale.forLanguageTag("ar-u-nu-latn"))
        gregTv.text = f.format(Date())
        hijriTv.text = hijriText
    }

    // ---------- مواقيت الصلاة ----------
    private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun applyCachedPrayer() {
        val json = prefs.getString("prayer_json", null) ?: return
        try {
            parsePrayer(json)
        } catch (_: Exception) {
        }
    }

    private fun parsePrayer(json: String) {
        val d = JSONObject(json).getJSONObject("data")
        val t = d.getJSONObject("timings")
        val strs = prayerKeys.map { t.getString(it).substring(0, 5) }
        val mins = strs.map {
            val parts = it.split(":")
            parts[0].toInt() * 60 + parts[1].toInt()
        }
        val h = d.getJSONObject("date").getJSONObject("hijri")
        val month = h.getJSONObject("month").getString("ar")
            .replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        hijriText = "${h.getString("day").toInt()} $month ${h.getString("year")} هـ"
        prayerStrings = strs
        prayerMinutes = mins
    }

    private fun updatePrayerUi() {
        val mins = prayerMinutes ?: return
        val strs = prayerStrings ?: return
        for (i in 0 until 6) prayerTimeTvs[i].text = strs[i]

        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val found = countdownIdx.firstOrNull { mins[it] > now }
        val next = found ?: 0
        val diff = if (found == null) mins[0] + 1440 - now else mins[found] - now

        for (i in 0 until 6) {
            prayerRows[i].background = if (i == next) glass(22, 0xFF1E7BFF.toInt()) else null
        }
        val h = diff / 60
        val m = diff % 60
        val hPart = if (h > 0) "$h س و " else ""
        remainTv.text = "باقي $hPart$m د على ${prayerLabels[next]}"
    }

    // ---------- جلب البيانات ----------
    private fun refreshAll() {
        Thread {
            try { fetchPrayer() } catch (_: Exception) {}
            try { fetchWeather() } catch (_: Exception) {}
            try { fetchCurrency() } catch (_: Exception) {}
            try { fetchMatches() } catch (_: Exception) {}
        }.start()
    }

    private fun fetchPrayer() {
        val today = todayKey()
        val cached = prefs.getString("prayer_json", null)
        if (cached != null && prefs.getString("prayer_date", "") == today) {
            runOnUiThread { applyCachedPrayer(); updatePrayerUi(); updateGregorian() }
            return
        }
        val url = "https://api.aladhan.com/v1/timingsByCity?city=${Config.CITY}" +
                "&country=${Config.COUNTRY}&method=${Config.PRAYER_METHOD}"
        val body = Net.get(url)
        parsePrayer(body) // لو الشكل غلط يرمي استثناء قبل ما نحفظ
        prefs.edit().putString("prayer_json", body).putString("prayer_date", today).apply()
        runOnUiThread { updatePrayerUi(); updateGregorian() }
    }

    private fun fetchWeather() {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${Config.LAT}" +
                "&longitude=${Config.LON}&current=temperature_2m"
        val t = JSONObject(Net.get(url)).getJSONObject("current").getDouble("temperature_2m")
        val r = Math.round(t)
        runOnUiThread { weatherTv.text = "${Config.CITY_AR} $r°" }
    }

    private fun fetchCurrency() {
        val rate = JSONObject(Net.get("https://open.er-api.com/v6/latest/${Config.CURRENCY_FROM}"))
            .getJSONObject("rates").getDouble("EGP")
        val s = String.format(Locale.US, "%.2f", rate)
        runOnUiThread { currencyTv.text = "${Config.CURRENCY_LABEL}: $s ج.م" }
    }

    private fun fetchMatches() {
        if (Config.MATCHES_URL.isBlank()) return
        val arr = JSONArray(Net.get(Config.MATCHES_URL))
        val items = (0 until arr.length()).map { arr.getString(it) }
        runOnUiThread {
            if (items.isEmpty()) {
                tickerBar.visibility = View.GONE
            } else {
                tickerTv.text = items.joinToString("      •      ")
                tickerTv.isSelected = true
                tickerBar.visibility = View.VISIBLE
            }
        }
    }
}
