package com.mohamed.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class AppItem(val pkg: String, val label: String, val launch: Intent)

private class SettingRow(val title: String, val value: () -> String, val action: () -> Unit)

class MainActivity : Activity() {

    // ---------- حالة عامة ----------
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var uiLayer: FrameLayout
    private lateinit var dim: View
    private lateinit var tvView: TvView
    private var tvPlaying = false
    private var overlaysHidden = false

    private var scale = 1f
    private var W = 1920 // عرض الشاشة بوحدات التصميم (يتغير حسب نسبة الشاشة)
    private var H = 1080

    // إعدادات المستخدم
    private var lang = "ar"
    private var themeIdx = 0
    private var ownerName = Config.OWNER_NAME
    private var place: Place = Config.defaultPlace

    private val rtl: Boolean get() = lang == "ar"
    private val th: Theme get() = Places.themes[themeIdx]
    private val cardFill = 0x70000000
    private val lineColor = 0x40FFFFFF

    private fun tr(ar: String, en: String) = if (rtl) ar else en
    private fun alignEnd() = if (rtl) Gravity.END else Gravity.START
    private fun alignStart() = if (rtl) Gravity.START else Gravity.END
    private fun placeName() = tr(place.ar, place.en)

    private var installed: List<AppItem> = emptyList()
    private val iconCache = HashMap<String, Drawable?>()

    // الترتيب من الشمال لليمين
    private val tabDefs = listOf(
        Triple("launcher", "اللانشر", "Launcher"),
        Triple("settings", "التلفاز", "TV"),
        Triple("bluetooth", "بلوتوث", "Bluetooth"),
        Triple("inputs", "المداخل", "Inputs"),
        Triple("network", "الشبكة", "Network"),
        Triple("apps", "التطبيقات", "Apps"),
        Triple("home", "الرئيسية", "Home")
    )
    private val tabViews = LinkedHashMap<String, TextView>()
    private var selectedTab = "home"

    private lateinit var homeLayer: FrameLayout
    private lateinit var appsLayer: FrameLayout
    private lateinit var settingsLayer: FrameLayout
    private lateinit var appsGrid: GridView
    private lateinit var tileRow: LinearLayout

    private lateinit var weatherTv: TextView
    private lateinit var currencyTv: TextView
    private lateinit var ownerTv: TextView
    private lateinit var hijriTv: TextView
    private lateinit var gregTv: TextView
    private lateinit var remainTv: TextView
    private lateinit var tickerBar: View
    private lateinit var tickerTv: TextView

    private val prayerLabelsAr = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")
    private val prayerLabelsEn = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val prayerKeys = listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")
    private val countdownIdx = listOf(0, 2, 3, 4, 5) // الشروق مش صلاة في العد التنازلي
    private val prayerRows = ArrayList<View>()
    private val prayerTimeTvs = ArrayList<TextView>()
    private var prayerMinutes: List<Int>? = null
    private var prayerStrings: List<String>? = null
    private var hijriDay = 0
    private var hijriYear = ""
    private var hijriMonthAr = ""
    private var hijriMonthEn = ""

    // العملات
    private val rates = HashMap<String, Double>() // سعر الوحدة بالجنيه
    private val trend = HashMap<String, Int>()
    private var currencyIdx = 0

    // إعدادات اللانشر
    private val settingValueTvs = ArrayList<Pair<TextView, () -> String>>()

    private var lastRefresh = 0L

    private val tick = object : Runnable {
        override fun run() {
            updatePrayerUi()
            updateGregorian()
            if (System.currentTimeMillis() - lastRefresh > Config.REFRESH_MINUTES * 60_000L) {
                lastRefresh = System.currentTimeMillis()
                refreshAll()
            }
            ui.postDelayed(this, 15_000)
        }
    }

    private val rotateCurrency = object : Runnable {
        override fun run() {
            currencyIdx++
            currencyTv.animate().alpha(0f).setDuration(250).withEndAction {
                showCurrency()
                currencyTv.animate().alpha(1f).setDuration(250).start()
            }.start()
            ui.postDelayed(this, Config.CURRENCY_ROTATE_SECONDS * 1000L)
        }
    }

    private val ratesLoop = object : Runnable {
        override fun run() {
            Thread { try { fetchRates() } catch (_: Exception) {} }.start()
            ui.postDelayed(this, Config.RATES_REFRESH_MINUTES * 60_000L)
        }
    }

    // ---------- دورة الحياة ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        lang = prefs.getString("lang", "ar") ?: "ar"
        themeIdx = prefs.getInt("theme", 0).coerceIn(0, Places.themes.size - 1)
        ownerName = prefs.getString("owner", Config.OWNER_NAME) ?: Config.OWNER_NAME
        place = loadPlace()

        val dm = resources.displayMetrics
        scale = minOf(dm.widthPixels / 1920f, dm.heightPixels / 1080f)
        W = (dm.widthPixels / scale).toInt()
        H = (dm.heightPixels / scale).toInt()

        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.clipChildren = false

        // الطبقات من تحت لفوق: القناة (HDMI) ← تعتيم ← الواجهة
        tvView = TvView(this)
        tvView.visibility = View.GONE
        tvView.setCallback(object : TvView.TvInputCallback() {
            override fun onConnectionFailed(inputId: String?) {
                runOnUiThread { stopTv(); toast(tr("تعذّر تشغيل المدخل", "Could not open the input")) }
            }

            override fun onDisconnected(inputId: String?) {
                runOnUiThread { stopTv() }
            }
        })
        root.addView(tvView, FrameLayout.LayoutParams(-1, -1))
        dim = View(this)
        root.addView(dim, FrameLayout.LayoutParams(-1, -1))
        setDim(false)
        uiLayer = FrameLayout(this)
        uiLayer.layoutDirection = View.LAYOUT_DIRECTION_LTR
        uiLayer.clipChildren = false
        root.addView(uiLayer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildTopBar()
        buildHome()
        buildApps()
        buildSettings()

        installed = loadInstalled()
        applyCachedPrayer()
        if (prefs.getString("reopen", null) == "launcher") {
            prefs.edit().remove("reopen").apply()
            showLauncherSettings()
        } else {
            showHome()
        }
    }

    override fun onResume() {
        super.onResume()
        installed = loadInstalled()
        (appsGrid.adapter as? BaseAdapter)?.notifyDataSetChanged()
        rebuildHomeRow()
        resumeTv()
        ui.removeCallbacks(tick)
        tick.run()
        ui.removeCallbacks(ratesLoop)
        ratesLoop.run()
        ui.removeCallbacks(rotateCurrency)
        ui.postDelayed(rotateCurrency, Config.CURRENCY_ROTATE_SECONDS * 1000L)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
        ui.removeCallbacks(ratesLoop)
        ui.removeCallbacks(rotateCurrency)
        // نوقف القناة لما نطلع لتطبيق تاني، ونرجّعها في onResume
        tvView.reset()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.action == Intent.ACTION_MAIN) {
            setOverlays(true)
            showHome()
            tabViews["home"]?.requestFocus()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // اللانشر ما بيقفلش
        if (selectedTab != "home") {
            showHome()
            tabViews["home"]?.requestFocus()
        } else if (tvPlaying) {
            setOverlays(false) // إخفاء الواجهة وإظهار القناة بس
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (overlaysHidden) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE -> return super.dispatchKeyEvent(event)
            }
            // أي زرار تاني يرجّع الواجهة
            if (event.action == KeyEvent.ACTION_DOWN) setOverlays(true)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        }
    }

    // ---------- أدوات رسم ----------
    private fun px(v: Int): Int = (v * scale + 0.5f).toInt()

    private fun glass(radius: Int, fill: Int, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = px(radius).toFloat()
            setColor(fill)
            if (strokeW > 0) setStroke(px(strokeW), stroke)
        }

    private fun text(
        s: String,
        size: Int,
        color: Int = Color.WHITE,
        bold: Boolean = false,
        gravity: Int = alignEnd() or Gravity.CENTER_VERTICAL
    ): TextView = TextView(this).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px(size).toFloat())
        setTextColor(color)
        this.gravity = gravity
        includeFontPadding = false
        setShadowLayer(px(5).toFloat(), 0f, px(1).toFloat(), 0xB3000000.toInt())
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun FrameLayout.put(v: View, x: Int, y: Int, w: Int, h: Int) {
        val lp = FrameLayout.LayoutParams(px(w), px(h))
        lp.leftMargin = px(x)
        lp.topMargin = px(y)
        addView(v, lp)
    }

    private fun roundOutline(r: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, px(r).toFloat())
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> onPick(i) }
            .setNegativeButton(tr("إلغاء", "Cancel"), null)
            .show()
    }

    private fun askText(title: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.setText(initial)
        et.setSingleLine(true)
        et.inputType = InputType.TYPE_CLASS_TEXT
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(et)
            .setPositiveButton(tr("موافق", "OK")) { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton(tr("إلغاء", "Cancel"), null)
            .show()
    }

    private fun reopenSettings() {
        prefs.edit().putString("reopen", "launcher").apply()
        recreate()
    }

    // ---------- الشريط العلوي (بعرض الشاشة كلها) ----------
    private fun buildTopBar() {
        val bg = View(this)
        bg.background = glass(44, cardFill, lineColor, 2)
        uiLayer.put(bg, 40, 14, W - 80, 86)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.clipChildren = false
        bar.setPadding(px(32), 0, px(32), 0)
        uiLayer.put(bar, 40, 14, W - 80, 86)

        // الطقس + العملة (على الشمال)
        val info = LinearLayout(this)
        info.orientation = LinearLayout.VERTICAL
        info.gravity = Gravity.CENTER_VERTICAL
        weatherTv = text("${placeName()} --°", 24, 0xFFBFD4FF.toInt(), gravity = Gravity.START or Gravity.CENTER_VERTICAL)
        weatherTv.setSingleLine(true)
        currencyTv = text(tr("جارٍ تحميل الأسعار…", "Loading rates…"), 24, 0xFF7DB8FF.toInt(), gravity = Gravity.START or Gravity.CENTER_VERTICAL)
        currencyTv.setSingleLine(true)
        info.addView(weatherTv, LinearLayout.LayoutParams(-1, px(34)))
        info.addView(currencyTv, LinearLayout.LayoutParams(-1, px(34)))
        bar.addView(info, LinearLayout.LayoutParams(0, -1, 2.8f))

        // التبويبات: كل واحد بوزن متساوي فيملوا الشريط تلقائياً
        for ((id, ar, en) in tabDefs) {
            val tv = text(tr(ar, en), 28, gravity = Gravity.CENTER)
            tv.setSingleLine(true)
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.isFocusable = true
            tv.isClickable = true
            tv.setPadding(px(6), 0, px(6), 0)
            tv.setOnFocusChangeListener { _, _ -> styleTab(id) }
            tv.setOnClickListener { openTab(id) }
            val lp = LinearLayout.LayoutParams(0, px(62), 1.15f)
            lp.leftMargin = px(4)
            lp.rightMargin = px(4)
            bar.addView(tv, lp)
            tabViews[id] = tv
        }

        // اسم الشاشة (على اليمين)
        ownerTv = text(ownerName, 30, bold = true, gravity = Gravity.END or Gravity.CENTER_VERTICAL)
        ownerTv.setSingleLine(true)
        ownerTv.ellipsize = TextUtils.TruncateAt.END
        bar.addView(ownerTv, LinearLayout.LayoutParams(0, -1, 1.5f))
        styleAllTabs()
    }

    private fun styleTab(id: String) {
        val tv = tabViews[id] ?: return
        val selected = id == selectedTab
        val fill = if (selected) th.accent else 0
        val stroke = if (tv.isFocused) Color.WHITE else 0
        tv.background = glass(31, fill, stroke, 3)
    }

    private fun styleAllTabs() = tabViews.keys.forEach { styleTab(it) }

    private fun openTab(id: String) {
        when (id) {
            "home" -> showHome()
            "apps" -> showApps()
            "launcher" -> showLauncherSettings()
            "network" -> startFirst(
                Intent(Settings.ACTION_WIFI_SETTINGS),
                Intent(Settings.ACTION_WIRELESS_SETTINGS)
            )
            "bluetooth" -> startFirst(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "settings" -> startFirst(Intent(Settings.ACTION_SETTINGS)) // إعدادات التلفاز
            "inputs" -> openInputs()
        }
    }

    private fun startFirst(vararg intents: Intent) {
        for (i in intents) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (_: Exception) {
            }
        }
        toast(tr("الصفحة دي مش متاحة على الشاشة", "This page is not available on this TV"))
    }

    // ---------- القناة في الخلفية (مدخل HDMI) ----------
    private fun setDim(tvOn: Boolean) {
        val a1 = if (tvOn) 0xA6 else 0xCC
        val a2 = if (tvOn) 0x8C else 0xB3
        dim.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf((a1 shl 24) or th.top, (a2 shl 24) or th.bottom)
        )
    }

    private fun setOverlays(show: Boolean) {
        overlaysHidden = !show
        uiLayer.visibility = if (show) View.VISIBLE else View.GONE
        dim.visibility = if (show) View.VISIBLE else View.GONE
        if (show) {
            if (selectedTab == "apps") appsGrid.requestFocus() else tabViews["home"]?.requestFocus()
        }
    }

    private fun inputManager(): TvInputManager? =
        getSystemService(Context.TV_INPUT_SERVICE) as? TvInputManager

    private fun hdmiInputs(): List<TvInputInfo> = try {
        inputManager()?.tvInputList?.filter { it.isPassthroughInput } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    private fun startInput(info: TvInputInfo) {
        try {
            tvView.visibility = View.VISIBLE
            tvView.setStreamVolume(1f)
            tvView.tune(info.id, TvContract.buildChannelUriForPassthroughInput(info.id))
            prefs.edit().putString("input_id", info.id).apply()
            tvPlaying = true
            setDim(true)
        } catch (_: Exception) {
            stopTv()
            toast(tr("تعذّر تشغيل المدخل", "Could not open the input"))
        }
    }

    private fun stopTv() {
        try { tvView.reset() } catch (_: Exception) {}
        tvView.visibility = View.GONE
        tvPlaying = false
        setDim(false)
        if (overlaysHidden) setOverlays(true)
    }

    private fun resumeTv() {
        val saved = prefs.getString("input_id", null) ?: return
        val info = hdmiInputs().firstOrNull { it.id == saved } ?: return
        startInput(info)
    }

    private fun openInputs() {
        val inputs = hdmiInputs()
        if (inputs.isEmpty()) {
            openInputsFallback()
            return
        }
        val names = inputs.map { (it.loadCustomLabel(this) ?: it.loadLabel(this)).toString() }.toMutableList()
        names.add(tr("إيقاف القناة في الخلفية", "Stop background channel"))
        choose(tr("اختر المدخل", "Choose input"), names) { i ->
            if (i < inputs.size) {
                startInput(inputs[i])
                showHome()
                tabViews["home"]?.requestFocus()
            } else {
                prefs.edit().remove("input_id").apply()
                stopTv()
            }
        }
    }

    private fun openInputsFallback() {
        for (p in Config.INPUT_PACKAGES) {
            val i = packageManager.getLeanbackLaunchIntentForPackage(p)
                ?: packageManager.getLaunchIntentForPackage(p)
            if (i != null) {
                try {
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                    return
                } catch (_: Exception) {
                }
            }
        }
        toast(tr("عدّل INPUT_PACKAGES في Config.kt لتطبيق المداخل بتاع شاشتك", "Set INPUT_PACKAGES in Config.kt for your TV's input app"))
    }

    // ---------- الصفحة الرئيسية ----------
    private fun buildHome() {
        homeLayer = FrameLayout(this)
        homeLayer.clipChildren = false
        uiLayer.addView(homeLayer, FrameLayout.LayoutParams(-1, -1))

        // كارت مواقيت الصلاة
        val card = FrameLayout(this)
        card.clipChildren = false
        card.background = glass(46, cardFill, lineColor, 2)
        homeLayer.put(card, 125, 130, 770, 590)

        card.put(text(tr("مواقيت الصلاة • ${placeName()}", "Prayer times • ${placeName()}"), 36, bold = true), 24, 20, 722, 50)
        remainTv = text("", 26, th.accent)
        card.put(remainTv, 24, 68, 722, 38)

        for (i in 0 until 6) {
            val y = 118 + i * 78
            val rowBg = View(this)
            card.put(rowBg, 18, y, 734, 70)
            prayerRows.add(rowBg)
            val nameX = if (rtl) 300 else 30
            val timeX = if (rtl) 44 else 496
            card.put(text(tr(prayerLabelsAr[i], prayerLabelsEn[i]), 34), nameX, y, 432, 70)
            val t = text("--:--", 34, gravity = alignStart() or Gravity.CENTER_VERTICAL)
            card.put(t, timeX, y, 230, 70)
            prayerTimeTvs.add(t)
        }

        // التاريخ والساعة (ملتصقين بالجهة اليمنى مهما كان عرض الشاشة)
        val rx = W - 870
        hijriTv = text("", 42, bold = true)
        homeLayer.put(hijriTv, rx, 150, 810, 60)
        gregTv = text("", 30, 0xDDFFFFFF.toInt())
        homeLayer.put(gregTv, rx, 212, 810, 42)

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "h:mm"
        clock.timeZone = place.tz
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(250).toFloat())
        clock.setTextColor(0xF2FFFFFF.toInt())
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.includeFontPadding = false
        clock.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        clock.setShadowLayer(px(10).toFloat(), 0f, px(2).toFloat(), 0xB3000000.toInt())
        homeLayer.put(clock, W - 920, 270, 880, 270)

        homeLayer.put(text(tr("توقيت ${placeName()}", "${placeName()} time"), 28, 0xCCFFFFFF.toInt()), rx, 545, 810, 40)

        // شريط المباريات
        val tw = W - 185
        val bar = FrameLayout(this)
        bar.background = glass(30, cardFill, lineColor, 2)
        homeLayer.put(bar, 125, 748, tw, 62)
        tickerBar = bar
        val chip = text(tr("المباريات", "Matches"), 26, gravity = Gravity.CENTER)
        chip.background = glass(24, th.accent)
        bar.put(chip, tw - 176 - 12, 8, 176, 46)
        tickerTv = text("", 28)
        tickerTv.setSingleLine(true)
        tickerTv.ellipsize = TextUtils.TruncateAt.MARQUEE
        tickerTv.marqueeRepeatLimit = -1
        tickerTv.isSelected = true
        bar.put(tickerTv, 28, 6, tw - 176 - 70, 50)
        bar.visibility = View.GONE

        // لوحة التطبيقات (في نص الشاشة)
        val panel = FrameLayout(this)
        panel.clipChildren = false
        panel.background = glass(44, cardFill, lineColor, 2)
        homeLayer.put(panel, (W - 1450) / 2, 850, 1450, 190)

        val hsv = HorizontalScrollView(this)
        hsv.isHorizontalScrollBarEnabled = false
        hsv.clipToPadding = false
        hsv.clipChildren = false
        hsv.layoutDirection = View.LAYOUT_DIRECTION_LTR
        hsv.setPadding(px(24), 0, px(24), 0)
        tileRow = LinearLayout(this)
        tileRow.orientation = LinearLayout.HORIZONTAL
        tileRow.gravity = Gravity.CENTER_VERTICAL
        tileRow.clipChildren = false
        hsv.addView(tileRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        panel.put(hsv, 0, 0, 1450, 190)
    }

    private fun setLayer(home: Boolean, apps: Boolean, settings: Boolean) {
        homeLayer.visibility = if (home) View.VISIBLE else View.GONE
        appsLayer.visibility = if (apps) View.VISIBLE else View.GONE
        settingsLayer.visibility = if (settings) View.VISIBLE else View.GONE
    }

    private fun showHome() {
        selectedTab = "home"
        setLayer(true, false, false)
        styleAllTabs()
    }

    private fun showApps() {
        selectedTab = "apps"
        setLayer(false, true, false)
        styleAllTabs()
        appsGrid.requestFocus()
        if (installed.isNotEmpty()) appsGrid.setSelection(0)
    }

    private fun showLauncherSettings() {
        selectedTab = "launcher"
        setLayer(false, false, true)
        styleAllTabs()
        refreshSettingValues()
        (settingsLayer.getChildAt(1) as? ViewGroup)?.requestFocus()
        ui.post { settingsLayer.getChildAt(1)?.requestFocus() }
    }

    // ---------- شاشة كل التطبيقات ----------
    private fun buildApps() {
        appsLayer = FrameLayout(this)
        appsLayer.clipChildren = false
        uiLayer.addView(appsLayer, FrameLayout.LayoutParams(-1, -1))

        val cols = ((W - 300) / 230).coerceIn(5, 9)
        appsGrid = GridView(this).apply {
            numColumns = cols
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = px(14)
            horizontalSpacing = px(10)
            gravity = Gravity.CENTER
            clipToPadding = false
            setPadding(px(10), px(14), px(10), px(14))
            isFocusable = true
            selector = glass(28, 0x40FFFFFF, 0xFFFFFFFF.toInt(), 3)
            adapter = AppsAdapter()
            setOnItemClickListener { _, _, p, _ -> launch(installed[p]) }
            setOnItemLongClickListener { _, _, p, _ -> addToHome(installed[p]); true }
        }
        appsLayer.put(appsGrid, 150, 130, W - 300, 840)
        appsLayer.put(
            text(
                tr("اضغط مطوّلاً على أي تطبيق لإضافته للصفحة الرئيسية", "Long-press an app to add it to the home row"),
                26, 0xCCFFFFFF.toInt(), gravity = Gravity.CENTER
            ),
            150, 985, W - 300, 44
        )
        appsLayer.visibility = View.GONE
    }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = installed.size
        override fun getItem(position: Int) = installed[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val app = installed[position]
            val col = LinearLayout(this@MainActivity)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.layoutParams = AbsListView.LayoutParams(px(220), px(180))
            val iv = ImageView(this@MainActivity)
            iv.setImageDrawable(iconFor(app.pkg))
            col.addView(iv, LinearLayout.LayoutParams(px(96), px(96)))
            val tv = text(app.label, 24, gravity = Gravity.CENTER)
            tv.setSingleLine(true)
            tv.ellipsize = TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(px(200), px(44))
            lp.topMargin = px(10)
            col.addView(tv, lp)
            return col
        }
    }

    private fun iconFor(pkg: String): Drawable? = iconCache.getOrPut(pkg) {
        runCatching { packageManager.getApplicationIcon(pkg) }.getOrNull()
    }

    // ---------- شاشة إعدادات اللانشر ----------
    private fun buildSettings() {
        settingsLayer = FrameLayout(this)
        settingsLayer.clipChildren = false
        uiLayer.addView(settingsLayer, FrameLayout.LayoutParams(-1, -1))

        val rw = 1200
        val sx = (W - rw) / 2
        settingsLayer.put(
            text(tr("إعدادات اللانشر", "Launcher settings"), 44, bold = true, gravity = Gravity.CENTER),
            sx, 125, rw, 70
        )

        val rows = listOf(
            SettingRow(
                tr("الموقع (الدولة / المحافظة / المدينة)", "Location (country / region / city)"),
                { placeName() }, { pickCountry() }
            ),
            SettingRow(
                tr("طريقة حساب مواقيت الصلاة", "Prayer calculation method"),
                { methodLabel() }, { pickMethod() }
            ),
            SettingRow(
                tr("اللغة", "Language"),
                { if (rtl) "العربية" else "English" }, { pickLanguage() }
            ),
            SettingRow(
                tr("الثيم (الألوان)", "Theme (colors)"),
                { tr(th.ar, th.en) }, { pickTheme() }
            ),
            SettingRow(
                tr("اسم الشاشة", "Screen name"),
                { ownerName }, { editOwner() }
            ),
            SettingRow(
                tr("إعدادات التلفاز (النظام)", "TV settings (system)"),
                { "›" }, { openTab("settings") }
            )
        )

        settingValueTvs.clear()
        rows.forEachIndexed { i, r ->
            val row = FrameLayout(this)
            row.background = glass(24, cardFill, lineColor, 2)
            row.isFocusable = true
            row.isClickable = true
            focusEffect(row, 24, 1.03f)
            row.setOnClickListener { r.action() }

            val tx = if (rtl) rw - 30 - 620 else 30
            val vx = if (rtl) 30 else rw - 30 - 460
            row.put(text(r.title, 32), tx, 0, 620, 100)
            val vt = text(r.value(), 32, th.accent, bold = true, gravity = alignStart() or Gravity.CENTER_VERTICAL)
            vt.setSingleLine(true)
            vt.ellipsize = TextUtils.TruncateAt.END
            row.put(vt, vx, 0, 460, 100)
            settingValueTvs.add(Pair(vt, r.value))

            settingsLayer.put(row, sx, 215 + i * 114, rw, 100)
        }

        settingsLayer.put(
            text(
                tr("استخدم الأسهم للتنقل وزر OK للاختيار", "Use the arrows to move and OK to select"),
                26, 0xCCFFFFFF.toInt(), gravity = Gravity.CENTER
            ),
            sx, 215 + rows.size * 114 + 10, rw, 40
        )
        settingsLayer.visibility = View.GONE
    }

    private fun refreshSettingValues() {
        for ((tv, f) in settingValueTvs) tv.text = f()
    }

    private fun methodLabel(): String {
        val id = prefs.getInt("method", -1)
        val m = Places.methods.firstOrNull { it.id == id } ?: Places.methods[0]
        return tr(m.ar, m.en)
    }

    private fun pickMethod() {
        choose(
            tr("طريقة حساب المواقيت", "Calculation method"),
            Places.methods.map { tr(it.ar, it.en) }
        ) { i ->
            prefs.edit().putInt("method", Places.methods[i].id).remove("prayer_key").apply()
            reopenSettings()
        }
    }

    private fun pickLanguage() {
        choose("اللغة / Language", listOf("العربية", "English")) { i ->
            prefs.edit().putString("lang", if (i == 0) "ar" else "en").apply()
            reopenSettings()
        }
    }

    private fun pickTheme() {
        choose(tr("اختر الثيم", "Choose theme"), Places.themes.map { tr(it.ar, it.en) }) { i ->
            prefs.edit().putInt("theme", i).apply()
            reopenSettings()
        }
    }

    private fun editOwner() {
        askText(tr("اسم الشاشة", "Screen name"), ownerName) { s ->
            if (s.isNotEmpty()) {
                ownerName = s
                prefs.edit().putString("owner", s).apply()
                ownerTv.text = s
                refreshSettingValues()
            }
        }
    }

    // ---------- اختيار الموقع ----------
    private fun pickCountry() {
        val names = Places.countries.map { tr(it.ar, it.en) } +
                tr("🔍 بحث عن أي مدينة أخرى", "🔍 Search any other city")
        choose(tr("اختر الدولة", "Choose country"), names) { i ->
            if (i < Places.countries.size) pickPlace(Places.countries[i]) else searchCity()
        }
    }

    private fun pickPlace(c: Country) {
        choose(
            tr("${c.ar}: اختر المحافظة / المدينة", "${c.en}: choose region / city"),
            c.places.map { tr(it.ar, it.en) }
        ) { i -> setPlace(c.places[i]) }
    }

    private fun searchCity() {
        askText(tr("اكتب اسم المدينة", "Type a city name"), "") { q ->
            if (q.length < 2) return@askText
            toast(tr("جارٍ البحث…", "Searching…"))
            Thread {
                val res = try { Places.search(q, lang) } catch (_: Exception) { null }
                runOnUiThread {
                    when {
                        res == null -> toast(tr("تعذّر البحث، تأكد من الإنترنت", "Search failed, check the internet"))
                        res.isEmpty() -> toast(tr("لا توجد نتائج", "No results"))
                        else -> choose(
                            tr("اختر النتيجة", "Choose a result"),
                            res.map { it.sub.ifBlank { it.ar } }
                        ) { i -> setPlace(res[i]) }
                    }
                }
            }.start()
        }
    }

    private fun setPlace(p: Place) {
        prefs.edit()
            .putString("p_ar", p.ar)
            .putString("p_en", p.en)
            .putString("p_lat", p.lat.toString())
            .putString("p_lon", p.lon.toString())
            .putString("p_tz", p.tz)
            .putInt("p_method", p.method)
            .remove("prayer_key")
            .apply()
        reopenSettings()
    }

    private fun loadPlace(): Place {
        val lat = prefs.getString("p_lat", null)?.toDoubleOrNull()
        val lon = prefs.getString("p_lon", null)?.toDoubleOrNull()
        if (lat == null || lon == null) return Config.defaultPlace
        return Place(
            prefs.getString("p_ar", "") ?: "",
            prefs.getString("p_en", "") ?: "",
            lat, lon,
            prefs.getString("p_tz", "Africa/Cairo") ?: "Africa/Cairo",
            prefs.getInt("p_method", 3)
        )
    }

    // ---------- التطبيقات ----------
    private fun loadInstalled(): List<AppItem> {
        val pm = packageManager
        val map = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName == packageName || map.containsKey(ai.packageName)) continue
                val li = Intent(Intent.ACTION_MAIN)
                    .addCategory(cat)
                    .setClassName(ai.packageName, ai.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                map[ai.packageName] = AppItem(ai.packageName, ri.loadLabel(pm).toString(), li)
            }
        }
        return map.values.sortedBy { it.label.lowercase() }
    }

    private fun launch(app: AppItem) {
        try {
            startActivity(app.launch)
        } catch (_: Exception) {
            toast(tr("تعذّر فتح ${app.label}", "Could not open ${app.label}"))
        }
    }

    private fun homePackages(): MutableList<String> {
        val saved = prefs.getString("home_apps", null)
        if (saved != null) return saved.split(",").filter { it.isNotBlank() }.toMutableList()
        val have = installed.map { it.pkg }.toSet()
        val list = mutableListOf<String>()
        for (alts in Config.DEFAULT_APPS) alts.firstOrNull { it in have }?.let { list.add(it) }
        return list
    }

    private fun saveHome(list: List<String>) {
        prefs.edit().putString("home_apps", list.joinToString(",")).apply()
    }

    private fun addToHome(app: AppItem) {
        val l = homePackages()
        if (app.pkg in l) {
            toast(tr("${app.label} موجود بالفعل في الرئيسية", "${app.label} is already on the home row"))
        } else {
            l.add(app.pkg)
            saveHome(l)
            toast(tr("اتضاف ${app.label} للرئيسية", "${app.label} added to home"))
        }
    }

    private fun removeFromHome(app: AppItem) {
        val l = homePackages()
        l.remove(app.pkg)
        saveHome(l)
        rebuildHomeRow()
        tileRow.getChildAt(0)?.requestFocus()
        toast(tr("اتشال ${app.label} من الرئيسية", "${app.label} removed from home"))
    }

    private fun rebuildHomeRow() {
        tileRow.removeAllViews()
        val byPkg = installed.associateBy { it.pkg }
        for (p in homePackages()) {
            val app = byPkg[p] ?: continue
            tileRow.addView(makeAppTile(app), tileLp())
        }
        tileRow.addView(makeAddTile(), tileLp())
    }

    private fun tileLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(px(250), px(130))
        lp.leftMargin = px(14)
        lp.rightMargin = px(14)
        return lp
    }

    private fun focusEffect(tile: View, radius: Int, factor: Float = 1.08f) {
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = px(radius).toFloat()
            setColor(0)
            setStroke(px(4), Color.WHITE)
        }
        tile.setOnFocusChangeListener { v, focused ->
            val s = if (focused) factor else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            v.translationZ = if (focused) 12f else 0f
            v.foreground = if (focused) ring else null
        }
    }

    private fun makeAppTile(app: AppItem): View {
        val tile = FrameLayout(this)
        tile.background = glass(24, 0x40FFFFFF)
        tile.isFocusable = true
        tile.isClickable = true
        val banner = runCatching { packageManager.getApplicationBanner(app.pkg) }.getOrNull()
        if (banner != null) {
            val iv = ImageView(this)
            iv.setImageDrawable(banner)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.clipToOutline = true
            iv.outlineProvider = roundOutline(24)
            tile.addView(iv, FrameLayout.LayoutParams(-1, -1))
        } else {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val iv = ImageView(this)
            iv.setImageDrawable(iconFor(app.pkg))
            col.addView(iv, LinearLayout.LayoutParams(px(64), px(64)))
            val tv = text(app.label, 24, gravity = Gravity.CENTER)
            tv.setSingleLine(true)
            tv.ellipsize = TextUtils.TruncateAt.END
            val lp = LinearLayout.LayoutParams(px(220), px(34))
            lp.topMargin = px(6)
            col.addView(tv, lp)
            tile.addView(col, FrameLayout.LayoutParams(-1, -1))
        }
        focusEffect(tile, 24)
        tile.setOnClickListener { launch(app) }
        tile.setOnLongClickListener { removeFromHome(app); true }
        return tile
    }

    private fun makeAddTile(): View {
        val tile = FrameLayout(this)
        tile.background = glass(24, 0x30FFFFFF, lineColor, 2)
        tile.isFocusable = true
        tile.isClickable = true
        tile.addView(text("+", 70, gravity = Gravity.CENTER), FrameLayout.LayoutParams(-1, -1))
        focusEffect(tile, 24)
        tile.setOnClickListener {
            showApps()
            toast(tr("اضغط مطوّلاً على التطبيق لإضافته", "Long-press an app to add it"))
        }
        return tile
    }

    // ---------- التاريخ ----------
    private fun updateGregorian() {
        val f = if (rtl) SimpleDateFormat("EEEE، d MMMM", Locale.forLanguageTag("ar-u-nu-latn"))
        else SimpleDateFormat("EEEE, d MMMM", Locale.ENGLISH)
        f.timeZone = TimeZone.getTimeZone(place.tz)
        gregTv.text = f.format(Date())
        hijriTv.text = if (hijriDay > 0) {
            if (rtl) "$hijriDay $hijriMonthAr $hijriYear هـ" else "$hijriDay $hijriMonthEn $hijriYear AH"
        } else ""
    }

    // ---------- مواقيت الصلاة ----------
    private fun tz(): TimeZone = TimeZone.getTimeZone(place.tz)

    private fun dateKey(): String {
        val f = SimpleDateFormat("dd-MM-yyyy", Locale.US)
        f.timeZone = tz()
        return f.format(Date())
    }

    private fun method(): Int {
        val o = prefs.getInt("method", -1)
        return if (o >= 0) o else place.method
    }

    private fun cacheKey() = "${dateKey()}|${place.lat}|${place.lon}|${method()}"

    private fun applyCachedPrayer() {
        val json = prefs.getString("prayer_json", null) ?: return
        if (prefs.getString("prayer_key", "") != cacheKey()) return
        try {
            parsePrayer(json)
        } catch (_: Exception) {
        }
    }

    private fun parsePrayer(json: String) {
        val d = JSONObject(json).getJSONObject("data")
        val t = d.getJSONObject("timings")
        val strs = prayerKeys.map { t.getString(it).substring(0, 5) }
        val mins = strs.map {
            val parts = it.split(":")
            parts[0].toInt() * 60 + parts[1].toInt()
        }
        val h = d.getJSONObject("date").getJSONObject("hijri")
        val month = h.getJSONObject("month")
        hijriMonthAr = month.getString("ar").replace(Regex("[\\u064B-\\u065F\\u0670]"), "")
        hijriMonthEn = month.getString("en")
        hijriDay = h.getString("day").toInt()
        hijriYear = h.getString("year")
        prayerStrings = strs
        prayerMinutes = mins
    }

    private fun updatePrayerUi() {
        val mins = prayerMinutes ?: return
        val strs = prayerStrings ?: return
        for (i in 0 until 6) prayerTimeTvs[i].text = strs[i]

        val cal = Calendar.getInstance(tz())
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val found = countdownIdx.firstOrNull { mins[it] > now }
        val next = found ?: 0
        val diff = if (found == null) mins[0] + 1440 - now else mins[found] - now

        for (i in 0 until 6) {
            prayerRows[i].background = if (i == next) glass(22, th.accent) else null
        }
        val h = diff / 60
        val m = diff % 60
        val name = tr(prayerLabelsAr[next], prayerLabelsEn[next])
        remainTv.text = if (rtl) {
            val hPart = if (h > 0) "$h س و " else ""
            "باقي $hPart$m د على $name"
        } else {
            val hPart = if (h > 0) "$h h " else ""
            "$hPart$m m until $name"
        }
    }

    // ---------- جلب البيانات ----------
    private fun refreshAll() {
        Thread {
            try { fetchPrayer() } catch (_: Exception) {}
            try { fetchWeather() } catch (_: Exception) {}
            try { fetchMatches() } catch (_: Exception) {}
        }.start()
    }

    private fun fetchPrayer() {
        val key = cacheKey()
        val cached = prefs.getString("prayer_json", null)
        if (cached != null && prefs.getString("prayer_key", "") == key) {
            runOnUiThread { applyCachedPrayer(); updatePrayerUi(); updateGregorian() }
            return
        }
        val url = "https://api.aladhan.com/v1/timings/${dateKey()}?latitude=${place.lat}" +
                "&longitude=${place.lon}&method=${method()}" +
                "&timezonestring=" + URLEncoder.encode(place.tz, "UTF-8")
        val body = Net.get(url)
        parsePrayer(body) // لو الشكل غلط يرمي استثناء قبل ما نحفظ
        prefs.edit().putString("prayer_json", body).putString("prayer_key", key).apply()
        runOnUiThread { updatePrayerUi(); updateGregorian() }
    }

    private fun fetchWeather() {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}" +
                "&longitude=${place.lon}&current=temperature_2m"
        val t = JSONObject(Net.get(url)).getJSONObject("current").getDouble("temperature_2m")
        val r = Math.round(t)
        runOnUiThread { weatherTv.text = "${placeName()} $r°" }
    }

    /** أسعار العملات مقابل الجنيه (open.er-api.com: مصدر مجاني بيتحدّث عدة مرات يومياً) */
    private fun fetchRates() {
        val r = JSONObject(Net.get("https://open.er-api.com/v6/latest/EGP")).getJSONObject("rates")
        val updated = HashMap<String, Double>()
        for (c in Config.CURRENCIES) {
            val v = r.optDouble(c.code, 0.0)
            if (v > 0.0) updated[c.code] = 1.0 / v
        }
        runOnUiThread {
            for ((k, v) in updated) {
                val old = rates[k]
                if (old != null && Math.abs(old - v) > 0.0001) trend[k] = if (v > old) 1 else -1
                rates[k] = v
            }
            showCurrency()
        }
    }

    private fun showCurrency() {
        val list = Config.CURRENCIES.filter { rates.containsKey(it.code) }
        if (list.isEmpty()) return
        val c = list[currencyIdx % list.size]
        val price = String.format(Locale.US, "%.2f", rates[c.code])
        val sb = SpannableStringBuilder("${tr(c.ar, c.en)}: $price ${tr("ج.م", "EGP")}")
        val t = trend[c.code] ?: 0
        if (t != 0) {
            val start = sb.length
            sb.append(if (t > 0) " ▲" else " ▼")
            val col = if (t > 0) 0xFF34D399.toInt() else 0xFFF87171.toInt()
            sb.setSpan(ForegroundColorSpan(col), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        currencyTv.text = sb
    }

    private fun fetchMatches() {
        if (Config.MATCHES_URL.isBlank()) return
        val arr = JSONArray(Net.get(Config.MATCHES_URL))
        val items = (0 until arr.length()).map { arr.getString(it) }
        runOnUiThread {
            if (items.isEmpty()) {
                tickerBar.visibility = View.GONE
            } else {
                tickerTv.text = items.joinToString("      •      ")
                tickerTv.isSelected = true
                tickerBar.visibility = View.VISIBLE
            }
        }
    }
}
