package com.mohamed.tvlauncher

/**
 * كل الإعدادات اللي ممكن تعدّلها في مكان واحد.
 */
object Config {

    /** الاسم اللي بيظهر أعلى يمين الشاشة */
    const val OWNER_NAME = "شاشتي"

    /** المدينة (للصلاة والطقس) */
    const val CITY = "Cairo"
    const val COUNTRY = "Egypt"
    const val CITY_AR = "القاهرة"
    const val LAT = 30.0444
    const val LON = 31.2357

    /** طريقة حساب المواقيت: 5 = الهيئة المصرية العامة للمساحة */
    const val PRAYER_METHOD = 5

    /** العملة اللي هتتحول للجنيه المصري */
    const val CURRENCY_FROM = "SAR"
    const val CURRENCY_LABEL = "الريال"

    /**
     * رابط JSON اختياري لشريط المباريات.
     * الصيغة: مصفوفة نصوص، مثال:
     * ["الأهلي × الزمالك (اليوم 8:00 م • ستاد القاهرة الدولي)"]
     * سيبه فاضي لو مش عاوز الشريط.
     */
    const val MATCHES_URL = ""

    /** كم دقيقة بين كل تحديث للطقس والعملة والمباريات */
    const val REFRESH_MINUTES = 30

    /**
     * التطبيقات الافتراضية في الصف السفلي (أول حزمة متثبّتة من كل مجموعة هي اللي تظهر).
     * المستخدم يقدر يضيف ويحذف بنفسه بعد كده.
     */
    val DEFAULT_APPS: List<List<String>> = listOf(
        listOf("com.netflix.ninja", "com.netflix.mediaclient"),
        listOf("com.google.android.youtube.tv", "com.google.android.youtube"),
        listOf("com.spotify.tv.android", "com.spotify.music"),
        listOf("cm.aptoide.pt", "cm.aptoide.pt.tv"),
        listOf("com.liskovsoft.smarttubetv"),
        listOf("org.xbmc.kodi")
    )

    /**
     * حزم محتملة لتطبيق "المداخل" (HDMI / AV) على الشاشة.
     * بتختلف من firmware لآخر، عدّلها حسب شاشتك (شوف README).
     */
    val INPUT_PACKAGES: List<String> = listOf(
        "com.mediatek.wwtv.tvcenter",
        "com.mstar.tvsetting",
        "com.android.tv.settings.input",
        "com.google.android.tv",
        "com.android.tv"
    )
}
