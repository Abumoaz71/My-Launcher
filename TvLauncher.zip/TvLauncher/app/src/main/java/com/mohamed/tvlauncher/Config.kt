package com.mohamed.tvlauncher

data class Cur(val code: String, val ar: String, val en: String)

/**
 * الإعدادات الافتراضية. معظمها (الموقع، اللغة، الثيم، الاسم) بتتغيّر من شاشة "اللانشر" جوه التطبيق.
 */
object Config {

    /** الاسم الافتراضي أعلى يمين الشاشة (تقدر تغيّره من إعدادات اللانشر) */
    const val OWNER_NAME = "شاشتي"

    /** الموقع الافتراضي لأول تشغيل */
    val defaultPlace = Place("القاهرة", "Cairo", 30.0444, 31.2357, "Africa/Cairo", 5)

    /** العملات اللي بتتبدّل في الشريط العلوي (سعر الوحدة بالجنيه المصري) */
    val CURRENCIES: List<Cur> = listOf(
        Cur("USD", "الدولار", "US Dollar"),
        Cur("EUR", "اليورو", "Euro"),
        Cur("GBP", "الإسترليني", "Pound Sterling"),
        Cur("SAR", "الريال السعودي", "Saudi Riyal"),
        Cur("AED", "الدرهم الإماراتي", "UAE Dirham"),
        Cur("KWD", "الدينار الكويتي", "Kuwaiti Dinar"),
        Cur("QAR", "الريال القطري", "Qatari Riyal"),
        Cur("CAD", "الدولار الكندي", "Canadian Dollar")
    )

    /** كل كام ثانية تتبدّل العملة المعروضة */
    const val CURRENCY_ROTATE_SECONDS = 60

    /** كل كام دقيقة نجيب أسعار جديدة */
    const val RATES_REFRESH_MINUTES = 5

    /**
     * رابط JSON اختياري لشريط المباريات.
     * الصيغة: مصفوفة نصوص، مثال:
     * ["الأهلي × الزمالك (اليوم 8:00 م • ستاد القاهرة الدولي)"]
     * سيبه فاضي لو مش عاوز الشريط.
     */
    const val MATCHES_URL = ""

    /** كم دقيقة بين كل تحديث للطقس والمواقيت والمباريات */
    const val REFRESH_MINUTES = 30

    /** التطبيقات الافتراضية في الصف السفلي (أول حزمة متثبّتة من كل مجموعة هي اللي تظهر). */
    val DEFAULT_APPS: List<List<String>> = listOf(
        listOf("com.netflix.ninja", "com.netflix.mediaclient"),
        listOf("com.google.android.youtube.tv", "com.google.android.youtube"),
        listOf("com.spotify.tv.android", "com.spotify.music"),
        listOf("cm.aptoide.pt", "cm.aptoide.pt.tv"),
        listOf("com.liskovsoft.smarttubetv"),
        listOf("org.xbmc.kodi")
    )

    /** حزم احتياطية لتطبيق "المداخل" لو الشاشة مش بتعرض مداخل HDMI للتطبيقات. */
    val INPUT_PACKAGES: List<String> = listOf(
        "com.mediatek.wwtv.tvcenter",
        "com.mstar.tvsetting",
        "com.android.tv.settings.input",
        "com.google.android.tv",
        "com.android.tv"
    )
}
